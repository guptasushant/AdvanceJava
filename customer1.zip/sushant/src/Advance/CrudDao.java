package Advance;

public interface CrudDao {
	public abstract void Insert(Employees employees);
	public abstract void Display();
	public abstract void Search();
	public abstract void Delete();
	public abstract void Update();
}
